Coloca tu canción en esta carpeta con el nombre song.mp3.
La música solo se carga después de una interacción. Si falta, el juego sigue funcionando.
